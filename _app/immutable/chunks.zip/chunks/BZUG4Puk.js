import{C as a,P as t,f as e,g as n,h as o,S as P}from"./BzVk5r6l.js";const s=new a;s.setEndpoint(t).setProject(e);const r=new n(s);new o(s);const I=new P(s);export{r as d,I as s};
