function r(n){const u=n-1;return u*u*u+1}function c(n){return n/=.5,n<1?.5*n*n:(n--,-.5*(n*(n-2)-1))}export{r as c,c as q};
