const c=o=>typeof o=="function";function i(o,r){return typeof o=="string"?o=document.querySelectorAll(o):o instanceof Element&&(o=[o]),Array.from(o||[])}export{c as i,i as r};
