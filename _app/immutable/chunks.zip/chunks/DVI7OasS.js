import{q as o,E as f,v as i,w as p,h as c,x as h,y as d}from"./NgVQVlRK.js";function y(e,n,...t){var s=e,r=c,a;o(()=>{r!==(r=n())&&(a&&(p(a),a=null),a=i(()=>r(s,...t)))},f),h&&(s=d)}export{y as s};
