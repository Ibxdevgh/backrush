function c(a,t,n){return Math.min(Math.max(a,t),n)}export{c};
