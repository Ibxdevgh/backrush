const t=o=>{const e=()=>{window.scrollTo({top:0,behavior:"smooth"})};return o.addEventListener("click",e),{destroy(){o.removeEventListener("click",e)}}};export{t as s};
