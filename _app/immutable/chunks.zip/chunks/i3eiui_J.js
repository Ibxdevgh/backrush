const n=a=>a;export{n as a};
