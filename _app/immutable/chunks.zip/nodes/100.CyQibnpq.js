import{a as e}from"../chunks/rPvk_irr.js";export{e as component};
