import{a as e}from"../chunks/_ai-1AJ1.js";export{e as component};
