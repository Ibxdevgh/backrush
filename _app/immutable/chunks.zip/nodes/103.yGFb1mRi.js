import{a as e}from"../chunks/BjMfL1xa.js";export{e as component};
