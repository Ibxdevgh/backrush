import{a as e}from"../chunks/Dl_vqeN7.js";export{e as component};
