import{a as e}from"../chunks/B4mm9BDu.js";export{e as component};
