import{a as e}from"../chunks/B7Ul92Sk.js";export{e as component};
