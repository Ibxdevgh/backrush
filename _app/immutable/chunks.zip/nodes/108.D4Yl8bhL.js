import{a as e}from"../chunks/DLJV39I0.js";export{e as component};
