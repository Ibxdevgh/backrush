import{a as e}from"../chunks/Ba3WYbRt.js";export{e as component};
