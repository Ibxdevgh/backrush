import{a as e}from"../chunks/BQTyL0u7.js";export{e as component};
