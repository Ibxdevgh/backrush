import{a as e}from"../chunks/D0PEKRl8.js";export{e as component};
