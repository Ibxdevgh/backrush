import{a as e}from"../chunks/DEOueCx9.js";export{e as component};
