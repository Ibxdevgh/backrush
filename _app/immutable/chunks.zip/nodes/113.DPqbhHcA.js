import{a as e}from"../chunks/CI9guxRv.js";export{e as component};
