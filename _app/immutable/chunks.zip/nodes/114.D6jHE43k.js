import{a as e}from"../chunks/jg5pXtco.js";export{e as component};
