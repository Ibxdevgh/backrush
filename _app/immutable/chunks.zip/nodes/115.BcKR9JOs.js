import{a as e}from"../chunks/DNcfTdxa.js";export{e as component};
