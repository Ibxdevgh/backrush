import{a as e}from"../chunks/BxqzmGud.js";export{e as component};
