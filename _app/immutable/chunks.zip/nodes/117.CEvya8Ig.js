import{a as e}from"../chunks/DHpuvVfR.js";export{e as component};
