import{a as e}from"../chunks/1asxx3_C.js";export{e as component};
