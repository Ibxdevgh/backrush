import{a as e}from"../chunks/CTPuDVIf.js";export{e as component};
