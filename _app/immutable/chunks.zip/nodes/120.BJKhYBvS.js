import{a as e}from"../chunks/B0Awnf77.js";export{e as component};
