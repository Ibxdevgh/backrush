import{a as e}from"../chunks/DMfx89Es.js";export{e as component};
