import{a as e}from"../chunks/CM9UrDdZ.js";export{e as component};
