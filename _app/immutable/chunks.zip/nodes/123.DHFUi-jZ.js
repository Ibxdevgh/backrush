import{a as e}from"../chunks/U4u83BRa.js";export{e as component};
