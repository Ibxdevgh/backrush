import{a as e}from"../chunks/DaBKTlSj.js";export{e as component};
