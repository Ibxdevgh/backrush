import{a as e}from"../chunks/C3b6C-RC.js";export{e as component};
