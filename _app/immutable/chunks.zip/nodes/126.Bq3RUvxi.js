import{a as e}from"../chunks/CP1p-98E.js";export{e as component};
