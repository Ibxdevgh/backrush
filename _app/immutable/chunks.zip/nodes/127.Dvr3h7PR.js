import{a as e}from"../chunks/DL5HeH8B.js";export{e as component};
