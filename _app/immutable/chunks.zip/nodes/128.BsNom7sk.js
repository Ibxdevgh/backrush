import{a as e}from"../chunks/C6Sy-Bvb.js";export{e as component};
