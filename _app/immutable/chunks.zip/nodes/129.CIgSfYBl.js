import{a as e}from"../chunks/qOEtPqsF.js";export{e as component};
