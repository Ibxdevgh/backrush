import{a as e}from"../chunks/DpeKq0Ub.js";export{e as component};
