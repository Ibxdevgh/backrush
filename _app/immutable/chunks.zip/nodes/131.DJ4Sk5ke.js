import{a as e}from"../chunks/CK7fABI2.js";export{e as component};
