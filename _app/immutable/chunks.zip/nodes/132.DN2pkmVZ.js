import{a as e}from"../chunks/CYriHZgX.js";export{e as component};
