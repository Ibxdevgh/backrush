import{a as e}from"../chunks/DxJMsadf.js";export{e as component};
