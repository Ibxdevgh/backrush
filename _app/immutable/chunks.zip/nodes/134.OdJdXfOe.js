import{a as e}from"../chunks/BuDlXg3A.js";export{e as component};
