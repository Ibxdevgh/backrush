import{a as e}from"../chunks/Cq5fVVf8.js";export{e as component};
