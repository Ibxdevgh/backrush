import{a as e}from"../chunks/6FFbNeAi.js";export{e as component};
